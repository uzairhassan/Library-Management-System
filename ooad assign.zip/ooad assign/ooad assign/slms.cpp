#include "slms.h"
#include "String"
#include "lms.h"
lms * slms::mysystem=nullptr;
