#pragma once
#include "slms.h"
#include "book.h"
#include "admin.h"
#include "loan.h"
#include "user.h"
#include "clerk.h"
#include "item.h"
#include "dvd.h"
#include "student.h"
#include "lms.h"
#include <string>
#include <iostream>
#include <ctime>
#include "hold.h"
#include <msclr\marshal_cppstd.h>
#include <fstream>
#include <vector>
using namespace std;
using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;
using namespace msclr::interop;
using namespace System::Data::SqlClient;
using namespace MySql::Data::MySqlClient;
using namespace System::Text;
class computation
{
	slms sys;
	
public:
	computation();
	string search(string t, int choice)
	{
		lms * l = sys.getmysystem();
		string ans;
		if (choice == 0)
		{
			l->searchbytitle(t, ans);
		}
		else if (choice == 1)
		{
			l->searchbysubject(t, ans);
		}
		if (choice == 2)
		{
			l->searchbyauthor(t, ans);
		}
		return ans;
	}
	string retuser(int id)
	{
		string ans;
		lms * l = sys.getmysystem();
		l->printborrower(id, ans);
		return ans;
	}
	int addloan(user * tu, item * ti)
	{
		
			time_t t = time(0);
			struct tm * now = localtime(&t);
			int y = now->tm_year;
			y = y + 1900;
			int m = now->tm_mon;
			int d = now->tm_mday;
			loan * l = new loan(y, m, d, tu, ti);
			int res = (ti->addloan(l));
			if (res == 1)
			{
				tu->addloan(l);
				return res;
			}
			else
			{
				return res;
			}
	}
	int issue(int choice, int id, std::string t)
	{
		lms * l = sys.getmysystem();
		user * tu = l->returnuser(id);
		if (tu != nullptr)
		{
			if (choice == 0)
			{
				item * ti = l->returnbook(t);
				if (ti != nullptr)
				{
					return(addloan(tu, ti));
				}
				else
				{
					return 2;
				}
			}
			else
			{
				item * ti = l->returndvd(t);
				if (ti != nullptr)
				{
					return(addloan(tu, ti));
				}
				else
				{
					return 2;
				}
			}
		}
		else
		{
			return 0;
		}
	}
	int ret(int choice, int id, std::string t)
	{
		time_t w = time(0);
		struct tm * now = localtime(&w);
		int y = now->tm_year;
		y = y + 1900;
		int m = now->tm_mon;
		int d = now->tm_mday;
		lms * l = sys.getmysystem();
		user * tu = l->returnuser(id);
		if (tu != nullptr)
		{
			if (choice == 0)
			{
				item * ti = l->returnbook(t);
				if (ti != nullptr)
				{
					if (ti->isissued())
					{
						return(ti->returnback(y, m, d));
					}
					else
					{
						return 3;
					}
				}
				else
				{
					return 2;
				}
			}
			else
			{
				item * ti = l->returndvd(t);
				if (ti != nullptr)
				{
					return(ti->returnback(y, m, d));
				}
				else
				{
					return 2;
				}
			}
		}
		else
		{
			return 0;
		}
	}
	void payfine(int id)
	{
		lms * l = sys.getmysystem();
		user * u = l->returnuser(id);
		u->payfine();
	}
	void addborrower(std::string n, std::string a, std::string c)
	{
		lms * l = sys.getmysystem();
		user * u = new student(n);
		u->setaddress(a);
		u->setphonenum(c);
		l->adduser(u);
	}
	void retuserdata(int id, std::string &n, std::string &a, std::string &c)
	{
		lms * l = sys.getmysystem();
		user * u = l->returnuser(id);
		n = u->getname();
		a = u->getaddress();
		c = u->getcontact();
	}
	void setuserdata(int id, std::string n, std::string a, std::string c)
	{
		lms * l = sys.getmysystem();
		user * u = l->returnuser(id);
		u->setname(n);u->setaddress(a);u->setphonenum(c);
	}
	void addbook(std::string t, std::string s, std::string a, int p,std::string state)
	{
		item * it = new book(t,s,a,p,state);
		lms * l = sys.getmysystem();
		l->additem(it);
	}
	void adddvd(std::string t, std::string s, float ss, std::string state)
	{
		item * it = new dvd(t, s, ss,state);
		lms * l = sys.getmysystem();
		l->additem(it);
	}
	void retbook(std::string search,std::string &t, std::string &s, std::string &a, int &p)
	{
		lms* l = sys.getmysystem();
		item * it=l->returnbook(search);
		t=it->gettitle();
		s = it->getsubject();
		a = it->getauthor();
		p = it->getpages();
	}
	void retdvd(std::string search, std::string &t, std::string &s, float &p)
	{
		lms* l = sys.getmysystem();
		item * it = l->returndvd(search);
		t = it->gettitle();
		s = it->getsubject();
		p = it->getsize();
	}
	void setdvd(std::string search,std::string &t, std::string &s, float &p)
	{
		lms* l = sys.getmysystem();
		item * it = l->returndvd(search);
		it->settitle(t);
		it->setsubject(s);
		it->setsize(p);
	}
	void setbook(std::string search,::string &t, std::string &s, std::string &a, int &p)
	{
		lms* l = sys.getmysystem();
		item * it = l->returnbook(search);
		it->settitle(t);it->setpages(p);it->setauthor(a);it->setsubject(s);
	}
	int delbook(std::string t)
	{
		lms * l = sys.getmysystem();
		return(l->removebook(t));
	}
	int deldvd(std::string t)
	{
		lms * l = sys.getmysystem();
		return(l->removedvd(t));
	}
	int addhold(user * tu, item * ti)
	{

			if (ti->isissued())
			{
				std::vector<loan *> userloans = tu->retloans();
				for (int i = 0;i < userloans.size();i++)
				{
					if (userloans[i]->getitemid() == ti->getid() && userloans[i]->issued())
					{
						return 4;
					}
				}

				std::queue<hold* > userholds = tu->retholds();
				for (int i = 0; userloans.size()>0;i++)
				{
					hold * h = userholds.front();
					userholds.pop();
					if (h->getiid() == ti->getid())
					{
						return 5;
					}
				}
				hold * h = new hold(tu, ti);
			    
				return 1;
			}
			else
			{
				return 0;
			}
	}
	int holdd(int id, int id2)
	{
		lms * l = sys.getmysystem();
		item * it = l->searchbyid(id);
		user * u = l->returnuser(id2);
		if (u != nullptr)
		{
			if (it != nullptr)
			{
				return addhold(u, it);
			}
			else
			{
				return 2;
			}
		}
		else
		{
			return 3;
		}
	}
	void save()
	{
		ofstream sl,sh,su,si;
		sl.open("saveloans.txt");
		sh.open("saveholds.txt");
		su.open("saveusers.txt");
		si.open("saveitems.txt");
		lms * l = sys.getmysystem();
		l->saveusers(su);
		l->saveitems(si);
		l->saveloans(sl);
		l->saveholds(sh);
	}
std::vector<int> newsave()
{
	std::vector<int>fines;
	String^ constring = L"datasource=localhost;port=3306;username=root;password=hack hack123";
	MySqlConnection^ condatabase = gcnew MySqlConnection(constring);	
	condatabase->Open();
	MySqlCommand^ cmddatabase1 = gcnew MySqlCommand("delete from assign2.lmsusers;", condatabase);
	MySqlDataReader^ myreader1 = cmddatabase1->ExecuteReader();
	myreader1->Close();
	MySqlCommand^ cmddatabase2 = gcnew MySqlCommand("delete from assign2.loans;", condatabase);
	MySqlDataReader^ myreader2 = cmddatabase2->ExecuteReader();
	myreader2->Close();
	MySqlCommand^ cmddatabase3 = gcnew MySqlCommand("delete from assign2.books;", condatabase);
	MySqlDataReader^ myreader3 = cmddatabase3->ExecuteReader();
	myreader3->Close();
	MySqlCommand^ cmddatabase4 = gcnew MySqlCommand("delete from assign2.dvd;", condatabase);
	MySqlDataReader^ myreader4 = cmddatabase4->ExecuteReader();
	myreader4->Close();
	MySqlCommand^ cmddatabase5 = gcnew MySqlCommand("delete from assign2.holds;", condatabase);
	MySqlDataReader^ myreader5 = cmddatabase5->ExecuteReader();
	myreader5->Close();
	std::vector<user *> utemp=sys.getmysystem()->retusers();
		for (int i = 0;i < utemp.size();i++)
		{
			String^ name = marshal_as<String^>(utemp[i]->getname());
			String^ contact = marshal_as<String^>( utemp[i]->getcontact());
			String^ address = marshal_as<String^>(utemp[i]->getaddress());
			String^ password = marshal_as<String^>(utemp[i]->getpassword());
			String^ utype = marshal_as<String^>(utemp[i]->gettype());
			int uid = utemp[i]->getid();
			MySqlCommand^ cmddatabase = gcnew MySqlCommand("insert into  assign2.lmsusers (id,uname,uphonenum,uaddress,upassword,type) values ('"+uid+"','"+name+"','"+contact+"','"+address+"','"+password+"','"+utype+"');", condatabase);
			
			MySqlDataReader^ myreader=cmddatabase->ExecuteReader();
			myreader->Close();
		}

		std::vector<item *> itemp = sys.getmysystem()->retitems();
		for (int i = 0;i < itemp.size();i++)
		{
			if (itemp[i]->isbook())
			{
				int iid = itemp[i]->getid();
				String^ ititle = marshal_as<String^>(itemp[i]->gettitle());
				String^ isubject = marshal_as<String^>(itemp[i]->getsubject());
				String^ iauthor = marshal_as<String^>(itemp[i]->getauthor());
				int ipages = itemp[i]->getpages();
				String^ itype = marshal_as<String^>(itemp[i]->getstate());
				MySqlCommand^ cmddatabase = gcnew MySqlCommand("insert into  assign2.books  values ('" + iid + "','" + ititle + "','" + isubject + "','" + iauthor + "','" + ipages + "','" + itype + "');", condatabase);
				MySqlDataReader^ myreader = cmddatabase->ExecuteReader();
				myreader->Close();
			}
			else if (itemp[i]->isdvd())
			{
				int iid = itemp[i]->getid();
				String^ ititle = marshal_as<String^>(itemp[i]->gettitle());
				String^ isubject = marshal_as<String^>(itemp[i]->getsubject());
			//	String^ iauthor = marshal_as<String^>(itemp[i]->getauthor());
				float isize = itemp[i]->getsize();
				String^ itype = marshal_as<String^>(itemp[i]->getstate());
				MySqlCommand^ cmddatabase = gcnew MySqlCommand("insert into  assign2.dvd  values ('" + iid + "','" + ititle + "','" + isubject + "','" + isize + "','" + itype + "');", condatabase);
				MySqlDataReader^ myreader = cmddatabase->ExecuteReader();
				myreader->Close();
			}
		}
		std::vector<loan *> loans;
		std::queue<hold *> holds;
		for (int i = 0;i < utemp.size();i++)
		{
			loans.clear();
			loans = utemp[i]->retloans();
			for (int j = 0;j < loans.size();j++)
			{
				int uid = loans[j]->getid();
				int iid = loans[j]->getitemid();
				int iday, imonth, iyear, rday, rmonth, ryear;
				loans[j]->getissuedate(iyear, imonth, iday);
				loans[j]->getretdate(ryear, rmonth, rday);
				int lfine = loans[j]->getfine();
				fines.push_back(lfine);
				MySqlCommand^ cmddatabase = gcnew MySqlCommand("insert into  assign2.loans  values ('" + uid + "','" + iid + "','" + iday + "','" + imonth + "','" + iyear + "','" + rday + "','" + rmonth + "','" + ryear + "','" + lfine + "');", condatabase);
				MySqlDataReader^ myreader = cmddatabase->ExecuteReader();
				myreader->Close();
			}
		}
		for (int i = 0;i < utemp.size();i++)
		{
			holds.empty();
			holds = utemp[i]->retholds();
			for (int j = 0; holds.size()>0;j++)
			{
				hold * h = holds.front();
				holds.pop();
				int uid = h->getuid();
				int iid = h->getiid();
				MySqlCommand^ cmddatabase = gcnew MySqlCommand("insert into  assign2.holds  values ('" + uid + "','" + iid + "');", condatabase);
				MySqlDataReader^ myreader = cmddatabase->ExecuteReader();
				myreader->Close();
			}
		}
		condatabase->Close();
		return fines;
}
std::vector<int>  load()
{
	String^ constring = L"datasource=localhost;port=3306;username=root;password=hack hack123";
	MySqlConnection^ condatabase = gcnew MySqlConnection(constring);
	condatabase->Open();
	MySqlCommand^ cmddatabase1 = gcnew MySqlCommand("select * from assign2.lmsusers;", condatabase);
	MySqlDataReader^ myreader1 = cmddatabase1->ExecuteReader();
	while (myreader1->Read())
	{
		std::string idd = marshal_as<string>(myreader1->GetString("id"));
		int id = stoi(idd);
		std::string name = marshal_as<string>(myreader1->GetString("uname"));
		std::string contact = marshal_as<string>(myreader1->GetString("uphonenum"));
		std::string password = marshal_as<string>(myreader1->GetString("upassword"));
		std::string address = marshal_as<string>(myreader1->GetString("uaddress"));
		std::string type = marshal_as<string>(myreader1->GetString("type"));
		if (type == "a")
		{
			sys.getmysystem()->adduser(new admin(id,name,contact,address,password));
		}
		else if (type == "c")
		{
			sys.getmysystem()->adduser(new clerk(id, name, contact, address, password));
		}
		else if (type == "s")
		{
			sys.getmysystem()->adduser(new student(id, name, contact, address, password));
		}
	}
	myreader1->Close();
	MySqlCommand^ cmddatabase2 = gcnew MySqlCommand("select * from assign2.books;", condatabase);
	MySqlDataReader^ myreader2 = cmddatabase2->ExecuteReader();
	while (myreader2->Read())
	{
		std::string idd= marshal_as<string>(myreader2->GetString("id"));
		int id = stoi(idd);
		std::string title = marshal_as<string>(myreader2->GetString("title"));
		std::string subject = marshal_as<string>(myreader2->GetString("subj"));
		std::string author = marshal_as<string>(myreader2->GetString("author"));
		std::string pg = marshal_as<string>(myreader2->GetString("pages"));
		int pages = stoi(pg);
		std::string type = marshal_as<string>(myreader2->GetString("typ"));
		item * it = new book(title, type);
		it->setsubject(subject);it->setauthor(author);it->setpages(pages);it->setid(id);
		sys.getmysystem()->additem(it);
	}
	myreader2->Close();

	MySqlCommand^ cmddatabase3 = gcnew MySqlCommand("select * from assign2.dvd;", condatabase);
	MySqlDataReader^ myreader3 = cmddatabase3->ExecuteReader();
	while (myreader3->Read())
	{
		std::string idd = marshal_as<string>(myreader3->GetString("id"));
		int id = stoi(idd);
		std::string title = marshal_as<string>(myreader3->GetString("title"));
		std::string subject = marshal_as<string>(myreader3->GetString("subj"));
	//	std::string author = marshal_as<string>(myreader1->GetString("author"));
		std::string sz = marshal_as<string>(myreader3->GetString("size"));
		float size = stof(sz);
		std::string type = marshal_as<string>(myreader3->GetString("typ"));
		item * it = new dvd(title, type);
		it->setsubject(subject);it->setsize(size);it->setid(id);
		sys.getmysystem()->additem(it);
	}

	myreader3->Close();

	MySqlCommand^ cmddatabase4 = gcnew MySqlCommand("select * from assign2.loans;", condatabase);
	MySqlDataReader^ myreader4 = cmddatabase4->ExecuteReader();
	std::vector<int>fines;
	while (myreader4->Read())
	{
		int userid = (myreader4->GetInt32("userid"));
		int itemid = (myreader4->GetInt32("itemid"));
		int iday = (myreader4->GetInt32("issueday"));
		int imonth = (myreader4->GetInt32("issuemonth"));
		int iyear = (myreader4->GetInt32("issueyear"));
		int rmonth = (myreader4->GetInt32("retmonth"));
		int ryear = (myreader4->GetInt32("retyear"));
		int rday = (myreader4->GetInt32("retday"));
		int fine = (myreader4->GetInt64("fine"));
		fines.push_back(fine);
		/*String^ message = "DVD has Loans can't delete";
		MessageBox::Show(this, message);*/
		user * u = sys.getmysystem()->returnuser(userid);
		item * it = sys.getmysystem()->searchbyid(itemid);
		loan * lo = new loan(iyear, imonth, iday, u, it);
		lo->setfine(fine);
		lo->setret(ryear, rmonth, rday);
		u->addloan(lo);it->addloan(lo);
	}
	myreader4->Close();

	MySqlCommand^ cmddatabase5 = gcnew MySqlCommand("select * from assign2.holds;", condatabase);
	MySqlDataReader^ myreader5 = cmddatabase5->ExecuteReader();
	while (myreader5->Read())
	{
		int userid = (myreader5->GetInt32("uid"));
		int itemid = (myreader5->GetInt32("iid"));
		user * u = sys.getmysystem()->returnuser(userid);
		item * it = sys.getmysystem()->searchbyid(itemid);
		hold * h = new hold(u, it);
	}
	myreader5->Close();
	condatabase->Close();
	return fines;
}
};

