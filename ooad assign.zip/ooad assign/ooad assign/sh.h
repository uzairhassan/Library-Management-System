#pragma once
class state;
class sh
{
	static state * s;
public:
	sh();
	state * gms();
	~sh();
};

