#include "clerk.h"


clerk::clerk()
{
}

clerk::clerk(std::string n) :user(n)
{
}


clerk::~clerk()
{
}
