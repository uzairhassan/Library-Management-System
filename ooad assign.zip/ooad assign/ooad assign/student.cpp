#include "student.h"


student::student()
{
}

student::student(std::string n) :user(n)
{
}

student::~student()
{
}
