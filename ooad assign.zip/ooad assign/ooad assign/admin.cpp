#include "admin.h"


admin::admin()
{
}

admin::admin(std::string n) :user(n)
{
}

admin::~admin()
{
}
