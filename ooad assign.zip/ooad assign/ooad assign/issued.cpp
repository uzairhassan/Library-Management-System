#include "issued.h"


issued::issued()
{
}
