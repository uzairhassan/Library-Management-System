#pragma once

class state;
class sa
{
	static state * s;
public:
	sa();
	state * gms();
	~sa();
};

