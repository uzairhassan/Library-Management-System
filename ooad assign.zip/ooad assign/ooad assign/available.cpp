#include "available.h"



available::available()
{
}
