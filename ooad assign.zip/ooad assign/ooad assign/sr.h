#pragma once
#include "referenced.h"
class state;
class sr
{
	static state * s;
public:
	sr();
	~sr();
	state * gms();

};

