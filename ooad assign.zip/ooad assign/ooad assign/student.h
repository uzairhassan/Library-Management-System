#pragma once
#include "user.h"
class student:public user
{
public:
	student();
	virtual void hehe(){}
	student(std::string);
	~student();
	virtual int isstudent() { return 1; }
	virtual int isclerk() { return 0; }
	virtual int isadmin() { return 0; }
	std::string gettype()
	{
		std::string res = "s";
		return res;
	}
	student(int id, std::string name, std::string contact, std::string address, std::string password):user(id,name,contact,address,password)
	{

	}
};

