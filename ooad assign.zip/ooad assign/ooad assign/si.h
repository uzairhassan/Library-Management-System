#pragma once

class state;
class si
{
	static state * s;
public:
	si();
	~si();
	state * gms();
};

