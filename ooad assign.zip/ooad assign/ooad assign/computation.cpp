#include "computation.h"



computation::computation()
{
	
}
