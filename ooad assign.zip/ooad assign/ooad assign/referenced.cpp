#include "referenced.h"



referenced::referenced()
{
}
