#pragma once

#include "state.h"
#include "sa.h"
#include "si.h"
#include "sh.h"
#include <ctime>
#include "user.h"
 class issued: public state 
{
	 
public:
	virtual  std::string getstate()
	{
		std::string res = "i";
		return res;
	}
	bool hasloan(item * it)
	{
		if (it->loans.size() > 0)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	  int returnlastid(item * it) {
		  if (it->loans.size() > 0)
		  {
			  return(it->loans[it->loans.size() - 1]->getid());
		  }
		  else
		  {
			  return -1;
		  }
	  }
	  void addhold(item * it, hold * h)
	  {
		  it->holds.push(h);
		  it->st=it->shs->gms();
	  }
	  bool isissued(item * it) {
		if (it->loans.size() > 0)
		{
			return(it->loans[it->loans.size() - 1]->issued());
		}
		return 0;
	}
	  bool onhold(item * it) { return 0; }
	  void printt(item * it, std::string &ans) { ans = ans + "Is issued\n"; }
	  int addloan(item * it, loan *) { return 3; }
	  int returnback(item * it, int y, int m, int d)
	  {
		  it->loans[it->loans.size() - 1]->setreturn(y, m, d);
		  if(it->holds.size()>0)
		  {
			  hold * h = it->holds.front();
			  it->holds.pop();
			  time_t w = time(0);
			  struct tm * now = localtime(&w);
			  int y = now->tm_year;
			  y = y + 1900;
			  int m = now->tm_mon;
			  int d = now->tm_mday;
			  loan * l = new loan(y, m, d, h->retuserpointer(), it);
			  it->addloan(l);
			  h->retuserpointer()->addloan(l);
			  if (it->holds.size() > 0)
			  {
				  it->st = it->sas->gms();
				  return 1;
			  }
			  else
			  {
				  it->st = it->sas->gms();
				  return 1;
			  }
		  }
		  else
		  {
			  it->st = it->sas->gms();
			  return 1;
		  }
		
	  }
	issued();
	 loan * returnlastloan(item * it) 
	 {
		 if (!it->onhold() && it->loans.size()>0)
		 {
			 return(it->loans[it->loans.size() - 1]);
		 }
		 else
		 {
			 return nullptr;
		 }
	 }
};

